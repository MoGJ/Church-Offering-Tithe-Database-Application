package com.nava.maasar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MaasarApplicationTests {

	@Test
	void contextLoads() {
	}

}
