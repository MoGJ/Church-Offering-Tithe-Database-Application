package com.nava.maasar;

/**
 *
 * @author j713n
 */
public class My_Maasar_v01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Menu_GUI testT = new Menu_GUI();
        testT.show();
        
    }
    
}
